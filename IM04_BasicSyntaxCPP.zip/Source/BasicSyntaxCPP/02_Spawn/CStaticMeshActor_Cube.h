#pragma once

#include "CoreMinimal.h"
#include "02_Spawn/CStaticMeshActorBase.h"
#include "CStaticMeshActor_Cube.generated.h"

UCLASS()
class BASICSYNTAXCPP_API ACStaticMeshActor_Cube : public ACStaticMeshActorBase
{
	GENERATED_BODY()

public:
	ACStaticMeshActor_Cube();
	
};
