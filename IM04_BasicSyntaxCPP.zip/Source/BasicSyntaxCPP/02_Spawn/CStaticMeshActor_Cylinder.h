#pragma once

#include "CoreMinimal.h"
#include "02_Spawn/CStaticMeshActorBase.h"
#include "CStaticMeshActor_Cylinder.generated.h"

UCLASS()
class BASICSYNTAXCPP_API ACStaticMeshActor_Cylinder : public ACStaticMeshActorBase
{
	GENERATED_BODY()

public:
	ACStaticMeshActor_Cylinder();
	
};
